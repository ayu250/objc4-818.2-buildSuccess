//
//  MRCARC.h
//  TestARCLayouts
//
//  Created by Patrick Beard on 3/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ARCBase.h"

@interface MRCARC : ARCBase
@property(retain) id dataSource;
@end
