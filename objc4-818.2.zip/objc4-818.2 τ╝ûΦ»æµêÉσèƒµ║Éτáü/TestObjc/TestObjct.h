//
//  TestObjct.h
//  TestObjc
//
//  Created by huang ruixu on 2021/6/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestObjct : NSObject
@property(nonatomic,copy) NSString *str;
@end

NS_ASSUME_NONNULL_END
