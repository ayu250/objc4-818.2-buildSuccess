//
//  main.m
//  TestObjc
//
//  Created by huang ruixu on 2021/6/15.
//

#import <Foundation/Foundation.h>
#import "TestObjct.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        TestObjct *obj = [TestObjct alloc];
        [obj init];
        obj.str = @"haha";
        NSLog(@"%p",obj);
    }
    return 0;
}
